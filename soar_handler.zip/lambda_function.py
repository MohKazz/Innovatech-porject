import boto3, json, os, datetime

ec2 = boto3.client('ec2')
elb = boto3.client('elbv2')
s3  = boto3.client('s3')

QUARANTINE_SG   = os.environ['QUARANTINE_SG']
EVIDENCE_BUCKET = os.environ['EVIDENCE_BUCKET']
TARGET_GROUP_ARN = os.environ.get('TARGET_GROUP_ARN', '')

def _instance_ids_from_event(event):
    ids = set()
    for f in event.get("detail", {}).get("findings", []):
        # Primary: normalized SecurityHub resource entries
        for r in f.get("Resources", []):
            if r.get("Type") in ("AwsEc2Instance",):
                rid = r.get("Id","")
                if ":instance/" in rid:
                    ids.add(rid.split(":instance/")[-1])
                elif rid.startswith("i-"):
                    ids.add(rid)
            # Fallback path: Details.AwsEc2Instance.InstanceId
            det = r.get("Details", {}).get("AwsEc2Instance", {})
            if isinstance(det, dict) and det.get("InstanceId"):
                ids.add(det["InstanceId"])
    return list(ids)

def _primary_enis(instance_id):
    res = ec2.describe_instances(InstanceIds=[instance_id])
    enis = []
    for r in res["Reservations"]:
        for inst in r["Instances"]:
            for ni in inst.get("NetworkInterfaces", []):
                # Quarantine all attached ENIs (safer)
                enis.append(ni["NetworkInterfaceId"])
    return enis

def _apply_isolation(eni_id):
    ec2.modify_network_interface_attribute(
        NetworkInterfaceId=eni_id,
        Groups=[QUARANTINE_SG]
    )

def _deregister_from_tg(instance_id):
    if not TARGET_GROUP_ARN:
        return
    try:
        elb.deregister_targets(
            TargetGroupArn=TARGET_GROUP_ARN,
            Targets=[{"Id": instance_id}]
        )
    except Exception as e:
        print(f"TargetGroup deregister warn for {instance_id}: {e}")

def _tag_quarantined(instance_id, reason):
    try:
        ec2.create_tags(Resources=[instance_id], Tags=[
            {"Key": "Quarantined", "Value": "true"},
            {"Key": "QuarantineReason", "Value": (reason or "")[:200]}
        ])
    except Exception as e:
        print(f"Tag warn for {instance_id}: {e}")

def handler(event, context):
    ts = datetime.datetime.utcnow().isoformat() + "Z"
    # Store full event as evidence
    key = f"securityhub/{ts}.json"
    s3.put_object(Bucket=EVIDENCE_BUCKET, Key=key,
                  Body=json.dumps(event, indent=2).encode("utf-8"),
                  ContentType="application/json")

    ids = _instance_ids_from_event(event)
    if not ids:
        print("No EC2 instances in finding")
        return {"status":"noop","evidence_key":key}

    # Best-effort friendly title
    title = ""
    try:
        title = event["detail"]["findings"][0].get("Title","")
    except Exception:
        pass

    isolated = []
    for iid in ids:
        try:
            enis = _primary_enis(iid)
            for eni in enis:
                _apply_isolation(eni)
            _deregister_from_tg(iid)
            _tag_quarantined(iid, title)
            isolated.append({"instance": iid, "enis": enis})
        except Exception as e:
            print(f"Quarantine error for {iid}: {e}")

    return {"status":"ok","evidence_key":key,"isolated":isolated}
